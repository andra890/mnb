# UserBot Broadcast

UserBot Telegram untuk broadcast pesan, forward, dan manajemen group list.

## 🚀 Deploy ke Heroku
Klik tombol di bawah untuk deploy langsung ke Heroku:

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/andra890/userbot)

---

## ⚙️ Config Vars yang dibutuhkan
Sebelum jalan, isi config vars di Heroku:

- `API_ID` → ambil dari [my.telegram.org](https://my.telegram.org)
- `API_HASH` → ambil dari [my.telegram.org](https://my.telegram.org)
- `SESSION_STRING` → hasil login Telethon (wajib)
- `OWNER_ID` → user ID Telegram kamu (misal `123456789`)

---

## 📌 Catatan
- Setelah deploy, masuk ke **Resources** → aktifkan dyno `worker`.
- Bot akan otomatis kirim pesan ke **Saved Messages**:
  ```
  💌 Sayang, aku udh aktif ~
  Ketik .menu ya ✨
  ```
